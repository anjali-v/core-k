

def on_button_press(button,data=None):
    print "button pressed"


def on_destroy(object,data=None):
    print "on_destroy"

